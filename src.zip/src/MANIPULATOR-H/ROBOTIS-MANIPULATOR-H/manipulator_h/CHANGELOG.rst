^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package manipulator_h
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.1 (2018-03-26)
------------------
* added roslib for catkin dependencies
* Contributors: Pyo

0.3.0 (2018-03-23)
------------------
* modified build option and dependencies
* changed license to Apache 2.0
* changed package.xml format to v2
* changed cmake & package setting for yaml-cpp
* changed manager's default value
* Contributors: SCH, Pyo

0.2.3 (2017-06-09)
------------------
* updated CMakeLists.txt & package.yaml to release binary packages
* Contributors: SCH

0.2.2 (2017-05-23)
------------------
* updated cmake file for ros install
* Contributors: SCH

0.2.1 (2016-09-22)
------------------
* manipulator_h_gui: package.xml cmake_modules dependency added
* manipulator_h_description: for indigo option
* Contributors: SCH

0.2.0 (2016-08-19)
-------------------
* added manipulator_h_gui package that GUI tool to control ROBOTIS MANIPULATOR-H
* Contributors: SCH

0.1.1 (2016-08-11)
-------------------
* first public release for Kinetic
* applied the semantic versioning
* add a meta-package
* Contributors: SCH, Pyo
