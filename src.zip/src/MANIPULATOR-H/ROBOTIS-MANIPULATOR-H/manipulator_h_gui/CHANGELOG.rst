^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package manipulator_h_gui
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.1 (2018-03-26)
------------------
* none

0.3.0 (2018-03-23)
------------------
* modified build option and dependencies
* changed license to Apache 2.0
* changed package.xml format to v2
* Contributors: Pyo

0.2.3 (2017-06-09)
------------------
* none

0.2.2 (2017-05-23)
------------------
* updated cmake file for ros install
* deleted logs
* Contributors: SCH

0.2.1 (2016-09-22)
------------------
* manipulator_h_gui: package.xml cmake_modules dependency added
* manipulator_h_description: for indigo option
* Contributors: SCH

0.2.0 (2016-08-19)
-------------------
* added manipulator_h_gui package that GUI tool to control ROBOTIS MANIPULATOR-H
* Contributors: SCH, Pyo
